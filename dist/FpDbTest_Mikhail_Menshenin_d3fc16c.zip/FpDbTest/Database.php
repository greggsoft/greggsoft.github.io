<?php

namespace FpDbTest;

use Exception;
use mysqli;

class Database implements DatabaseInterface
{
    private mysqli $mysqli;
    private $skipValue;

    public function __construct(mysqli $mysqli)
    {
        $this->mysqli = $mysqli;
    }

    public function buildQuery(string $query, array $args = []): string
    {
        $len = strlen($query);
        $result = '';
        $skipPart = '';
        $is_condition = false;
        $skip = false;

        for ($i = 0; $i < $len; $i++) {
            $symbol = $query[$i];

            if ($symbol === '?') {
                $next = $i < $len - 1 ? $query[$i + 1] : '';
                $value = array_shift($args);

                if ($is_condition) {
                    if (is_null($value)) {
                        $skip = true;
                    } else {
                        $this->skipValue = $value;
                    }
                }


                if (strpos('adf#', $next) !== false) {
                    $i++;
                }

                if (strpos('df', $next) !== false && is_null($value)) {
                    $value = 'NULL';
                } else
                if ($next === 'd') {
                    if (intval($value) != $value) {
                        throw new Exception("Wrong integer value");
                    }
                } else
                if ($next === 'f') {
                    if (doubleval($value) != $value) {
                        throw new Exception('Wrong float value');
                    }
                } else
                if ($next === '#') {
                    if (is_array($value)) {
                        $value = implode(', ', array_map(fn ($val) => $this->prepareKeyword($val), $value));
                    } else {
                        $value = $this->prepareKeyword($value);
                    }
                } else
                if ($next === 'a') {
                    if (array_is_list($value)) {
                        $value = implode(', ', array_map(fn ($val) => $this->prepareValueByType($val), $value));
                    } else {
                        $value = implode(', ', array_map(fn ($key) => $this->prepareKeyword($key) . ' = ' . $this->prepareValueByType($value[$key]), array_keys($value)));
                    }
                } else {
                    $value = $this->prepareValueByType($value);
                }

                if ($is_condition) {
                    $skipPart .= $value;
                } else {
                    $result .= $value;
                }
            } else
            if ($symbol === '{') {
                if ($is_condition) throw new Exception("Nested condition is not allowed");

                $is_condition = true;
                $skip = false;
            } else
            if ($symbol === '}') {
                if (!$skip) {
                    $result .= $skipPart;
                }
                $is_condition = false;
                $skip = false;
            } else {
                if ($is_condition) {
                    $skipPart .= $symbol;
                } else {
                    $result .= $symbol;
                }
            }
        }

        return $result;
    }

    public function skip()
    {
        return $this->skipValue;
    }

    private function prepareValueByType($value): string
    {
        if (is_string($value)) {
            $value = '\'' . $this->mysqli->real_escape_string($value) . '\'';
        }

        if (is_null($value)) {
            $value = 'NULL';
        }

        if (is_bool($value)) {
            $value = intval($value);
        }

        return $value . '';
    }

    private function prepareKeyword($value): string
    {
        if (!is_string($value)) {
            throw new Exception("Keyword can be string only");
        }

        if (strpos($value, '`') !== false) {
            throw new Exception('Bactick in keyword present');
        }

        $value = '`' . $this->mysqli->real_escape_string($value) . '`';

        return $value;
    }
}
