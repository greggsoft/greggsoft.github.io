<?php

namespace FpDbTest;

use Exception;

class DatabaseTest
{
    private DatabaseInterface $db;

    public function __construct(DatabaseInterface $db)
    {
        $this->db = $db;
    }

    public function testBuildQuery(): void
    {
        $results = [];

        $results[] = $this->db->buildQuery('SELECT name FROM users WHERE user_id = 1');

        $results[] = $this->db->buildQuery(
            'SELECT * FROM users WHERE name = ? AND block = 0',
            ['Jack']
        );

        $results[] = $this->db->buildQuery(
            'SELECT ?# FROM users WHERE user_id = ?d AND block = ?d',
            [['name', 'email'], 2, true]
        );

        $results[] = $this->db->buildQuery(
            'UPDATE users SET ?a WHERE user_id = -1',
            [['name' => 'Jack', 'email' => null]]
        );

        foreach ([null, true] as $block) {
            $results[] = $this->db->buildQuery(
                'SELECT name FROM users WHERE ?# IN (?a){ AND block = ?d}',
                ['user_id', [1, 2, 3], $block ?? $this->db->skip()]
            );
        }

        $correct = [
            'SELECT name FROM users WHERE user_id = 1',
            'SELECT * FROM users WHERE name = \'Jack\' AND block = 0',
            'SELECT `name`, `email` FROM users WHERE user_id = 2 AND block = 1',
            'UPDATE users SET `name` = \'Jack\', `email` = NULL WHERE user_id = -1',
            'SELECT name FROM users WHERE `user_id` IN (1, 2, 3)',
            'SELECT name FROM users WHERE `user_id` IN (1, 2, 3) AND block = 1',
        ];

        if ($results !== $correct) {
            throw new Exception('Failure.');
        }
    }

    public function testBuildQueryExtend(): void
    {
        $this->buildQueryAssertWithException(
            'SELECT name FROM users WHERE ?# IN (?a){ AND block = ?d{ OR block is null}}',
            ['user_id', [1, 2, 3], $block ?? $this->db->skip()],
            'There is no exception with nested condition'
        );
        $this->buildQueryAssertWithException(
            'SELECT ?# FROM users WHERE user_id = ?d AND block = ?d',
            [['name', 'email'], 2.2, true],
            'There is no exception with wrong integer parameter'
        );
        $this->buildQueryAssertWithException(
            'UPDATE cohort SET weight = ?f WHERE type = ?d',
            ['0.22-1', 2],
            'There is no exception with wrong float parameter'
        );
        $this->buildQueryAssert(
            'UPDATE cohort SET weight = ?f WHERE type = ?d',
            ['0.22', 2],
            'UPDATE cohort SET weight = 0.22 WHERE type = 2'
        );
        $this->buildQueryAssert(
            'UPDATE cohort SET weight = ?f WHERE type = ?d',
            [null, 2],
            'UPDATE cohort SET weight = NULL WHERE type = 2'
        );
        $this->buildQueryAssert(
            'UPDATE cohort SET weight = ?f WHERE type = ?d',
            ['0.22', null],
            'UPDATE cohort SET weight = 0.22 WHERE type = NULL'
        );
        foreach ([true, null] as $block) {
            $this->buildQueryAssert(
                'SELECT name FROM users WHERE ?# IN (?a){ AND block = ?d}',
                ['user_id', [1, 2, 3], $block ?? $this->db->skip()],
                'SELECT name FROM users WHERE `user_id` IN (1, 2, 3) AND block = 1'
            );
        }
        $this->buildQueryAssert(
            'UPDATE users SET name = ? WHERE id = ?d',
            ['Robert\'; DROP TABLE users;#--', 21222],
            'UPDATE users SET name = \'Robert\\\'; DROP TABLE users;#--\' WHERE id = 21222'
        );
        $this->buildQueryAssertWithException(
            'UPDATE users SET ?a WHERE user_id = ?d',
            [['name' => 'Jack\'; DROP TABLE users;#', 'email` = NULL; DROP TABLE users;#' => null], '123'],
            'There is no exception with backtick in keyword'
        );
        $this->buildQueryAssert(
            'UPDATE users SET ?a WHERE user_id = ?d',
            [['name' => 'Jack\'; DROP TABLE users;#', 'email' => null], '123'],
            'UPDATE users SET `name` = \'Jack\\\'; DROP TABLE users;#\', `email` = NULL WHERE user_id = 123'
        );
        $this->buildQueryAssert(
            'SELECT * FROM users WHERE name = ?',
            ['Jess'],
            'SELECT * FROM users WHERE name = \'Jess\''
        );
        $this->buildQueryAssert(
            'SELECT * FROM users WHERE name = ?',
            [null],
            'SELECT * FROM users WHERE name = NULL'
        );
    }

    private function buildQueryAssert(string $query, array $args, string $expected): void
    {
        $query = $this->db->buildQuery($query, $args);
        assert($query === $expected, "\nUnexpected query built: $query\nExpected: $expected\n");
    }

    private function buildQueryAssertWithException(string $query, array $args, string $message): void
    {
        $was_exception = false;
        try {
            $this->db->buildQuery($query, $args);
            $was_exception = false;
        } catch (\Throwable $th) {
            $was_exception = true;
        }
        assert($was_exception, $message);
    }
}
